from gpt_index.readers import Document
from langchain.text_splitter import CharacterTextSplitter, NLTKTextSplitter, SpacyTextSplitter, RecursiveCharacterTextSplitter

from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field, validator

from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory, CombinedMemory, ConversationSummaryBufferMemory, ConversationEntityMemory, ConversationBufferWindowMemory

from gpt_index import SimpleDirectoryReader, GPTTreeIndex, GPTListIndex, GPTSimpleVectorIndex, SummaryPrompt, GPTKeywordTableIndex, LLMPredictor
from langchain.chat_models import ChatOpenAI
import os, time
from termcolor import colored
from langchain.agents import Tool, tool

import sys
import json
from gpt_index.embeddings.openai import OpenAIEmbedding
import discord
import asyncio
import re
from langchain.chains.base import Chain
from typing import Dict, List, Any
from gpt_index.indices.base import BaseGPTIndex

embed_model = OpenAIEmbedding()


class DataLoader:
  """Data loader extracts documents from folders at `data.`"""

  def __init__(self, data_folder):
    self.data_folder = data_folder

  @staticmethod
  def extract_documents(folder_path: str, required_exts=['.txt', '.pdf']):
    # ...
    """This is a custom for-loop that is used to load .txt and pdf documents from the folder and subfolders. Needs more work"""

    #initialize lists
    docs = []

    #initialize PDF Doc Loaders
    doc_list = SimpleDirectoryReader(folder_path,
                                     recursive=True,
                                     required_exts=required_exts).load_data()

    for doc in doc_list:
      l = Document.to_langchain_format(doc)
      docs.append(l)

    return docs

  def load_documents(self, required_exts=['.txt', '.pdf']):
    """Use this method to load text and PDF documents from the data folder of this loader"""
    docs = self.extract_documents(self.data_folder, required_exts)
    return docs


class IndexManager:

  def __init__(self,
               data_dir: str,
               index_file_name: str,
               index_type: BaseGPTIndex,
               split_size=500):

    self.index_file_dir = data_dir + "/data" + "/" + index_file_name
    self.data_dir = data_dir

    self.data_loader = DataLoader(data_dir)
    self.index_type = index_type
    self.embed_model = OpenAIEmbedding()
    self.split_size = split_size

  @property
  def data_loader(self):
    return self._data_loader

  @data_loader.setter
  def data_loader(self, value):
    self._data_loader = value
    return self._data_loader

  #Method to create an index
  def create_index(self, docs: [Document]):

    if os.path.isfile(
        self.index_file_dir) and os.stat(self.index_file_dir).st_size != 0:

      print("INDEX FOUND")

      with open(self.index_file_dir, 'r') as file:
        i = file.read()
      index = self.index_type.load_from_disk(self.index_file_dir)
      #newindex = GPTSimpleVectorIndex.load_from_disk(self.index_dir,
      #embed_model=embed_model)

      print("LOADING INDEX! ")

    else:

      #create index file
      open(self.index_file_dir, 'w').close()
      print("Rebuild File: " + self.index_file_dir)
      for i, doc in enumerate(docs):
        print(f"Getting embedding for document {i}")
        emb = embed_model.get_text_embedding(doc.text)
        #emb = embed_model.get_text_embedding(lang_split_text.page_content)

        print(f"Finished embedding for document {i}")

        #inner doc get embedding (here we can add any metadata as well)
        doc.embedding = emb
        #index.insert(doc)

      index = self.index_type.from_documents(docs)
      index.save_to_disk(self.index_file_dir)
      print("CREATING INDEX!")
      #We end up with a vector index with each chunk having its own embedding, and embedding for all documents
    if index:
      print("Index Created!")
    return index

  # Method to load index
  def load_index(self):
    text_splitter = RecursiveCharacterTextSplitter(

      # Set a really small chunk size, just to show.
      chunk_size=self.split_size,
      chunk_overlap=100,
      length_function=len,
    )

    docs = text_splitter.split_documents(self.data_loader.load_documents())
    split_docs = []
    int = 0
    print("Splitting Documents: ")

    for i, lang_split_text in enumerate(docs):

      doc = Document.from_langchain_format(lang_split_text)
      split_docs.append(doc)
      int += 1
      print("Document: " + str(int))

    return self.create_index(split_docs)

  def save_index(self, index):
    open(self.index_file_dir, 'w').close()
    print("Rebuild File: " + self.index_file_dir)
    index.save_to_disk(self.index_file_dir)

  # Method to delete an index
  def delete_index(self):
    if os.path.exists(self.index_file_dir):
      os.remove(self.index_file_dir)
      print(f"Index file '{self.index_file_dir}' has been deleted.")
    else:
      print(f"Index file '{self.index_file_dir}' not found.")

  def load(self):
    self.index = self.load_index()
    return self.index
